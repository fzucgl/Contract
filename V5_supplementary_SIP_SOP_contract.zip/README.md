# Supplementary Material: SIP/SOP Contract (version 1.2.0)

Supplementary material for the paper *Contract-Driven Decoupled Scheduling Optimization Decision System in Power Battery Production* (Section IV-B, Table III).

## Contents

| Path | Content |
|---|---|
| `schema/sip-1.2.0.schema.json` | JSON Schema of the Standard Input Package (SIP) |
| `schema/sop-1.2.0.schema.json` | JSON Schema of the Standard Output Package (SOP) |
| `schema/envelope-1.0.schema.json` | Unified response envelope returned by every back-end interface |
| `examples/sip_example.json` | A valid SIP for the scenario of Section V-A |
| `examples/sop_example.json` | A valid SOP that answers `sip_example.json` |
| `examples/sip_invalid_missing_qty.json` | An invalid SIP (required field `demand[2].qty` missing) |
| `examples/response_422_schema_invalid.json` | Response to a schema-invalid SIP |
| `examples/response_409_version_mismatch.json` | Response to an incompatible contract version |
| `examples/response_ok.json` | Response to an accepted task |
| `tools_validate.py` | Minimal validator used to check the examples |

## Contract structure

| Paper term (Definition 2) | SIP / SOP field |
|---|---|
| Task metadata (incl. routing key R = ⟨B, S, A, V⟩) | `meta` |
| Order demand | `demand[]` |
| BOM | `bom[]` |
| Resource capability | `resources[]`, `routing[]` |
| Inventory and work in process | `inventory[]` |
| Constraint parameters | `constraints`, `extensions` |
| Algorithm parameters | `algorithm_params` |
| Solution status | `sop.status` |
| Planning and scheduling details | `sop.plan[]`, `sop.schedule[]` |
| Procurement suggestions | `sop.procurement[]` |
| KPIs | `sop.kpi` |
| Alarms and diagnostic information | `sop.alarms[]`, `sop.diagnostics` |

## Compatibility policy (semantic versioning)

* **Minor increment** (`sip-1.2.0` → `sip-1.3.0`): may add **optional** fields only. The router accepts it.
* **Major increment** (`sip-1.x.x` → `sip-2.0.0`): incompatible. The router refuses the call before invoking the algorithm and returns `409 VERSION_MISMATCH` (see `examples/response_409_version_mismatch.json`).
* The contract version is written into the task snapshot.

## Mapping of model variables to contract fields (Table III of the paper)

| Variable | Contract field | Unit |
|---|---|---|
| p | `demand[].product_id` | – |
| s | `resources[].stage` | – |
| d | `horizon` (`start`, `days`) | d |
| r | `bom[].mat_id` | – |
| x_psd | `sop.plan[].qty` | unit of stage s (`resources[].count_unit`) |
| α_rps | `bom[].per_unit` | – |
| Q_r^raw | `sop.procurement[].qty` | unit of material r |
| t_j | `routing[].proc_time` | min |
| m_sd | `resources[].machines` | – |
| T_d | `resources[].avail_time` | min/d |
| C_max | `sop.kpi.makespan` | h |
| C_cost | `sop.kpi.cost` | CNY |
| V_cap | `sop.kpi.cap_viol` | min |
| w_i | `objective.w` (order given by `objective.terms`) | – |
| y^lb, y^ub | `objective.bounds` | unit of y |

Normalization, Eq. (3): ỹ = (y − y^lb) / (y^ub − y^lb) for y ∈ {C_max, C_cost, V_cap}.

## Battery-specific extensions (optional)

| Constraint | SIP field | SOP answer |
|---|---|---|
| Grading consistency (cells of one module share a capacity / internal-resistance grade) | `extensions.grading.group_key` | `sop.plan[].batch_binding` |
| Minimum dwell of formation and aging between stages 1 and 2 | `extensions.dwell.min_hours` | dates in `sop.plan[]` |
| Module-to-pack (and cell-to-module) ratio | `bom[].per_unit` with `kind = "intermediate"` | quantities in `sop.plan[]` |

An algorithm that ignores `extensions` remains contract-conformant. Algorithms may add fields to `extensions` but must not change the meaning of core fields.

## Checks performed by the back end beyond the schema

JSON Schema cannot express the following rules; the back end checks them:

1. `sum(objective.w) = 1` and `objective.bounds.*.ub > objective.bounds.*.lb`.
2. The SOP refers to the task, products, stages, and dates of its SIP; units agree with `resources[].count_unit`.
3. Capacity constraint, Eq. (2): for each stage s and date d, Σ qty × proc_time ≤ machines × avail_time. An SOP with `kpi.cap_viol.v > 0` fails validation and the task moves to the failed state.

## About the examples

The scenario parameters of `sip_example.json` follow Section V-A:
* two products, ModelA and ModelB;
* a 7-day horizon;
* 40 packs per product and day;
* 2/2/1 machines at the cell, module, and pack stages;
* 840 min of daily available time per machine.

All other values are **illustrative** and chosen to make the pair consistent:
* processing times;
* BOM ratios;
* material identifiers;
* bounds and weights;
* the KPI values of the SOP.

The example SOP satisfies Eq. (2) with zero capacity violation. It is **not** the result shown in Fig. 4 of the paper.

## Validation

```bash
python tools_validate.py examples/sip_example.json schema/sip-1.2.0.schema.json
python tools_validate.py examples/sop_example.json schema/sop-1.2.0.schema.json
# or, with the jsonschema package:
python -m jsonschema -i examples/sip_example.json schema/sip-1.2.0.schema.json
```
