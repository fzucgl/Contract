"""Minimal JSON-Schema (draft-07 subset) validator used to check the examples.
Supports: type, required, properties, additionalProperties, items, enum, const,
minimum, exclusiveMinimum, minItems, maxItems, minLength, pattern, $ref.
With the 'jsonschema' package installed, prefer:  python -m jsonschema -i x.json s.json"""
import json, re, sys
T={"object":dict,"array":list,"string":str,"boolean":bool}
def v(inst,sch,root,path,errs):
    if "$ref" in sch:
        node=root
        for k in sch["$ref"].lstrip("#/").split("/"): node=node[k]
        return v(inst,node,root,path,errs)
    t=sch.get("type")
    if t:
        ok = (isinstance(inst,(int,float)) and not isinstance(inst,bool)) if t=="number" else \
             (isinstance(inst,int) and not isinstance(inst,bool)) if t=="integer" else isinstance(inst,T[t])
        if not ok: errs.append(f"{path}: expected {t}"); return
    if "const" in sch and inst!=sch["const"]: errs.append(f"{path}: const {sch['const']!r}")
    if "enum" in sch and inst not in sch["enum"]: errs.append(f"{path}: not in {sch['enum']}")
    if isinstance(inst,(int,float)) and not isinstance(inst,bool):
        if "minimum" in sch and inst<sch["minimum"]: errs.append(f"{path}: < minimum")
        if "exclusiveMinimum" in sch and inst<=sch["exclusiveMinimum"]: errs.append(f"{path}: <= exclusiveMinimum")
    if isinstance(inst,str):
        if "minLength" in sch and len(inst)<sch["minLength"]: errs.append(f"{path}: too short")
        if "pattern" in sch and not re.search(sch["pattern"],inst): errs.append(f"{path}: pattern")
    if isinstance(inst,list):
        if "minItems" in sch and len(inst)<sch["minItems"]: errs.append(f"{path}: minItems")
        if "maxItems" in sch and len(inst)>sch["maxItems"]: errs.append(f"{path}: maxItems")
        if "items" in sch:
            for i,x in enumerate(inst): v(x,sch["items"],root,f"{path}[{i}]",errs)
    if isinstance(inst,dict):
        for k in sch.get("required",[]):
            if k not in inst: errs.append(f"{path}.{k}: required")
        props=sch.get("properties",{})
        for k,x in inst.items():
            if k in props: v(x,props[k],root,f"{path}.{k}",errs)
            elif sch.get("additionalProperties",True) is False: errs.append(f"{path}.{k}: additional property")
def check(i,s):
    sch=json.load(open(s)); errs=[]; v(json.load(open(i)),sch,sch,"$",errs); return errs
if __name__=="__main__":
    e=check(sys.argv[1],sys.argv[2]); print("VALID" if not e else "INVALID:\n  "+"\n  ".join(e))
